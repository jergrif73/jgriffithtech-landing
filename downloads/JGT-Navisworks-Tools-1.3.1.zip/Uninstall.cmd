@echo off
rem JGT Navisworks Tools: removes the plugin for this Windows user.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1" -Uninstall %*

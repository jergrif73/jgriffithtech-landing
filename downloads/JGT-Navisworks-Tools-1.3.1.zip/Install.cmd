@echo off
rem JGT Navisworks Tools: installs for this Windows user. No admin rights needed.
rem For every user on the machine: right-click Install.cmd > Run as administrator, then run
rem   powershell -ExecutionPolicy Bypass -File "%~dp0Install.ps1" -AllUsers
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1" %*

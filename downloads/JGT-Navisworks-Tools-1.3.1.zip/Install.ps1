# JGT Navisworks Tools installer. Run Install.cmd (double-click), not this file directly.
# Copies ElementIdGrabber.bundle into the Autodesk plugin folder Navisworks loads at startup:
#   default    %APPDATA%\Autodesk\ApplicationPlugins      (this Windows user, no admin needed)
#   -AllUsers  %ProgramData%\Autodesk\ApplicationPlugins  (every user on the machine, needs admin)
param([switch]$AllUsers, [switch]$Uninstall)
$ErrorActionPreference = 'Stop'

function Done($msg, $color = 'Green') { Write-Host ''; Write-Host $msg -ForegroundColor $color; Write-Host ''; Read-Host 'Press Enter to close' | Out-Null }

$here = $PSScriptRoot
$bundleName = 'ElementIdGrabber.bundle'
$root = if ($AllUsers) { Join-Path $env:ProgramData 'Autodesk\ApplicationPlugins' } else { Join-Path $env:APPDATA 'Autodesk\ApplicationPlugins' }
$target = Join-Path $root $bundleName

Write-Host 'JGT Navisworks Tools' -ForegroundColor Yellow
Write-Host "Target: $target"

# Navisworks locks the installed plugin while it has it loaded, and only reads plugins at startup.
# Test the lock itself: a stray background Roamer.exe that never loaded the plugin doesn't block.
function Locked {
    $dll = Join-Path $target 'Contents\2026\ElementIdGrabber.dll'
    if (-not (Test-Path $dll)) { return $false }
    try { [IO.File]::Open($dll, 'Open', 'ReadWrite', 'None').Dispose(); return $false } catch { return $true }
}
while (Locked) {
    Write-Host ''
    Write-Host 'Navisworks is running with the JGT tools loaded. Save your work and close every Navisworks window.' -ForegroundColor Yellow
    $a = Read-Host 'Press Enter when it is closed (or type Q to quit)'
    if ($a -match '^[Qq]') { Done 'Nothing was changed.' 'Yellow'; exit 1 }
}
$stillRunning = [bool](Get-Process Roamer -ErrorAction SilentlyContinue)

if ($Uninstall) {
    if (Test-Path $target) { Remove-Item $target -Recurse -Force; Done 'JGT Navisworks Tools removed. Start Navisworks to confirm the JGT tab is gone.' }
    else { Done "Nothing to remove: $target does not exist." 'Yellow' }
    exit 0
}

$source = Join-Path $here $bundleName
if (-not (Test-Path (Join-Path $source 'PackageContents.xml'))) { Done "The $bundleName folder is missing next to Install.cmd. Unzip the whole package first." 'Red'; exit 1 }

if (-not (Test-Path 'C:\Program Files\Autodesk\Navisworks Manage 2026\Roamer.exe')) {
    Write-Host ''
    Write-Host 'Navisworks Manage 2026 was not found in the usual place. This package only loads in Navisworks Manage 2026.' -ForegroundColor Yellow
    $a = Read-Host 'Install anyway? (Y/N)'
    if ($a -notmatch '^[Yy]') { Done 'Nothing was changed.' 'Yellow'; exit 1 }
}

try {
    # Files from a downloaded or emailed zip are marked as "from the internet", and .NET refuses to load
    # a marked DLL. Clear the mark on everything first.
    Get-ChildItem $source -Recurse -File | Unblock-File
    if (Test-Path $target) { Remove-Item $target -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $root | Out-Null
    Copy-Item $source $target -Recurse -Force
    Get-ChildItem $target -Recurse -File | Unblock-File
}
catch {
    if ($AllUsers) { Done "Install failed: $($_.Exception.Message)`nInstall for all users needs Run as administrator." 'Red' }
    else { Done "Install failed: $($_.Exception.Message)" 'Red' }
    exit 1
}

[xml]$pc = Get-Content (Join-Path $target 'PackageContents.xml')
$msg = "Installed JGT Navisworks Tools " + $pc.ApplicationPackage.AppVersion + ".`nStart Navisworks Manage 2026 and open the JGT tab. Ctrl+Shift+X shows the Section pane."
if ($stillRunning) { $msg += "`nA Navisworks window is still open; the JGT tab appears the next time Navisworks starts." }
Done $msg
